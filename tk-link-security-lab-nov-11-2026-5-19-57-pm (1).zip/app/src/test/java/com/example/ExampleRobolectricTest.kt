package com.example

import com.example.data.SecurityLabData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleRobolectricTest {

    @Test
    fun testSecurityDataInitialized() {
        assertTrue(SecurityLabData.samplePhotos.isNotEmpty())
        assertTrue(SecurityLabData.mockMalwareApps.isNotEmpty())
        assertTrue(SecurityLabData.phishingUrlChecks.isNotEmpty())
        assertTrue(SecurityLabData.webHtmlCode.contains("TK LINK SECURITY LAB"))
        assertTrue(SecurityLabData.webCssCode.contains("cyber-theme"))
        assertTrue(SecurityLabData.webJsCode.contains("simulateLoginIntercept"))
    }

    @Test
    fun testSampleExifRiskRatings() {
        SecurityLabData.samplePhotos.forEach { photo ->
            assertTrue(photo.simulatedExif.gpsCoordinates.isNotEmpty())
            assertTrue(photo.simulatedExif.deviceModel.isNotEmpty())
        }
    }
}
