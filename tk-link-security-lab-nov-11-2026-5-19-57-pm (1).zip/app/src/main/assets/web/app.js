// TK Link Security Lab - Interactive Educational Logic
let currentLanguage = 'EN';

const translations = {
  EN: {
    disclaimer: "Educational lab for security awareness. Zero credential harvesting, zero hidden access, no data leaves your browser.",
    subTitle: "Phishing & Privacy Threat Defense Operations"
  },
  BN: {
    disclaimer: "শিক্ষামূলক সাইবার নিরাপত্তা ল্যাব। কোনো পাসওয়ার্ড বা গোপন ডেটা সংরক্ষণ হয় না।",
    subTitle: "ফিশিং এবং গোপনীয়তা ঝুঁকি প্রতিরোধ ও সচেতনতা ল্যাব"
  }
};

function toggleLanguage() {
  currentLanguage = currentLanguage === 'EN' ? 'BN' : 'EN';
  document.getElementById('disclaimer-text').textContent = translations[currentLanguage].disclaimer;
  document.getElementById('sub-title').textContent = translations[currentLanguage].subTitle;
}

function switchLab(tabId, el) {
  document.querySelectorAll('.lab-section').forEach(sec => sec.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
  document.getElementById(tabId).classList.add('active');
  if (el) el.classList.add('active');
}

function handleImageSelect(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(e) {
    document.getElementById('image-preview').src = e.target.result;
    document.getElementById('file-name-display').textContent = file.name + " (" + (file.size/1024).toFixed(1) + " KB)";
    document.getElementById('image-preview-container').style.display = 'block';
    document.getElementById('drop-zone').style.display = 'none';
  };
  reader.readAsDataURL(file);
}

function resetImage() {
  document.getElementById('file-input').value = '';
  document.getElementById('image-preview-container').style.display = 'none';
  document.getElementById('drop-zone').style.display = 'block';
}

function simulateLoginIntercept() {
  const pass = document.getElementById('demo-pass').value;
  const analysisBox = document.getElementById('phish-analysis-box');
  analysisBox.className = 'analysis-box active';
  analysisBox.innerHTML = `
    <div style="background:rgba(255,23,68,0.15); border:1px solid #FF1744; border-radius:8px; padding:14px;">
      <h4 style="color:#FF1744; margin-bottom:8px;">🚨 CREDENTIAL PHISHING INTERCEPTED!</h4>
      <p style="font-size:13px; margin-bottom:8px;"><strong>Simulated Intercepted Text:</strong> <span style="font-family:monospace; color:#00E5FF;">` + (pass ? '•'.repeat(pass.length) + ' (' + pass.length + ' chars)' : 'empty') + `</span></p>
      <p style="font-size:12px; color:#CBD5E1; line-height:1.5;">
        <strong>How it works:</strong> The URL <code>tk-secur1ty-lab.com</code> mimics the real portal. Malicious forms forward submitted keystrokes to an attacker-controlled server before redirecting to the real site to hide the intrusion.
      </p>
      <div style="margin-top:10px; font-size:12px; color:#00E676;">
        <strong>🛡️ Defense:</strong> Password managers automatically refuse to autofill on mismatched domain names!
      </div>
    </div>
  `;
}

function triggerCameraWarning(action) {
  alert("SIMULATION RESULT (" + action + "):\n\nNever grant camera permissions to untrusted reward sites or suspicious links. On Android 12+, notice the green camera dot in the top corner whenever any app activates the sensor!");
}

const mockApps = [
  { name: "Flashlight Ultra 2026", pkg: "com.flashlight.ultra", severity: "CRITICAL", vector: "Overlay Trojan + SMS Read" },
  { name: "Speed RAM Booster", pkg: "com.booster.ram", severity: "HIGH", vector: "Accessibility Service Abuse" },
  { name: "Cinema HD Streamer", pkg: "org.movie.free", severity: "HIGH", vector: "Cryptomining & Ad-Fraud" },
  { name: "TK Link Verified Browser", pkg: "com.tklink.browser", severity: "SAFE", vector: "Verified Clean" }
];

function runSimulatedScan() {
  const progressContainer = document.getElementById('progress-container');
  const progressFill = document.getElementById('progress-fill');
  const status = document.getElementById('scan-status');
  const container = document.getElementById('apps-container');

  progressContainer.style.display = 'block';
  status.textContent = "Scanning installed applications...";
  container.innerHTML = '';

  let pct = 0;
  const timer = setInterval(() => {
    pct += 25;
    progressFill.style.width = pct + '%';
    if (pct >= 100) {
      clearInterval(timer);
      status.textContent = "Scan Complete: 3 Potential Threats Flagged";
      renderApps();
    }
  }, 300);
}

function renderApps() {
  const container = document.getElementById('apps-container');
  container.innerHTML = mockApps.map(app => `
    <div class="cyber-card" style="border-left: 4px solid ` + (app.severity === 'SAFE' ? '#00E676' : '#FF1744') + `">
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <strong>` + app.name + `</strong>
        <span style="font-size:11px; padding:2px 8px; border-radius:4px; background:` + (app.severity === 'SAFE' ? '#00E676' : '#FF1744') + `; color:#000; font-weight:800;">` + app.severity + `</span>
      </div>
      <p style="font-size:12px; color:#94A3B8; margin:4px 0;">` + app.pkg + `</p>
      <p style="font-size:12px; color:#F8FAFC;"><strong>Vector:</strong> ` + app.vector + `</p>
    </div>
  `).join('');
}
