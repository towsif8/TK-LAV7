package com.example.data

import com.example.model.MockMalwareApp
import com.example.model.PhishingUrlCheck
import com.example.model.SamplePhoto
import com.example.model.SimulatedExif
import com.example.model.ThreatSeverity

object SecurityLabData {

    val samplePhotos = listOf(
        SamplePhoto(
            id = "photo_selfie",
            nameEn = "Home Portrait Selfie",
            nameBn = "বাসার প্রতিকৃতি সেলফি",
            category = "Personal / Residential",
            descriptionEn = "Captured indoors with front-facing camera. Malicious platforms extract exact living location and biometric facial markers.",
            descriptionBn = "সামনের ক্যামেরা দিয়ে ইনডোরে তোলা। ক্ষতিকর প্ল্যাটফর্ম এর মাধ্যমে বসবাসস্থল ও বায়োমেট্রিক তথ্য শনাক্ত করে।",
            simulatedExif = SimulatedExif(
                deviceModel = "Samsung Galaxy S24 Ultra (SM-S928B)",
                cameraLens = "12MP Front Camera, f/2.2, 26mm",
                timestamp = "2026-11-10 19:42:18 GMT+6",
                gpsCoordinates = "23.8103° N, 90.4125° E (Dhaka, Bangladesh)",
                locationName = "Gulshan-2 Residential Area, Dhaka",
                serialNumber = "SEC-R5CT90A11Z",
                privacyRisk = "CRITICAL: Contains exact residential GPS geotag, camera hardware ID, and high-resolution biometric face data.",
                privacyRiskBn = "মারাত্মক ঝুঁকি: সুনির্দিষ্ট বাসার অবস্থান (GPS), ক্যামেরার হার্ডওয়্যার আইডি এবং ফেসিয়াল বায়োমেট্রিক তথ্য বিদ্যমান।"
            )
        ),
        SamplePhoto(
            id = "photo_vacation",
            nameEn = "Tourist Landmark Photo",
            nameBn = "পর্যটন এলাকার ছবি",
            category = "Travel / Geolocation",
            descriptionEn = "Photo taken at a scenic spot. Attackers use this to profile travel schedules and verify empty homes.",
            descriptionBn = "পর্যটন স্থানে তোলা ছবি। আক্রমণকারীরা এটি বিশ্লেষণ করে বাড়ি ফাঁকা থাকার সুযোগ নেয়।",
            simulatedExif = SimulatedExif(
                deviceModel = "Apple iPhone 16 Pro Max",
                cameraLens = "48MP Main Camera, f/1.78, 24mm",
                timestamp = "2026-11-08 14:15:02 GMT+6",
                gpsCoordinates = "21.4272° N, 92.0058° E (Cox's Bazar)",
                locationName = "Laboni Beach, Cox's Bazar",
                serialNumber = "APL-F2LN88JK1W",
                privacyRisk = "HIGH: Reveals real-time travel whereabouts, vacation duration, and timestamp patterns.",
                privacyRiskBn = "উচ্চ ঝুঁকি: রিয়েল-টাইম ভ্রমণের সময়সূচি ও অবস্থান প্রকাশ করে।"
            )
        ),
        SamplePhoto(
            id = "photo_document",
            nameEn = "Work Desk & ID Card",
            nameBn = "অফিস ডেস্ক ও পরিচয়পত্র",
            category = "Identity / Confidential",
            descriptionEn = "Photo of a desk with an ID badge. Malicious sites use OCR and EXIF to harvest employee identity credentials.",
            descriptionBn = "ডেস্কের ওপর পরিচয়পত্র। ক্ষতিকর সাইটগুলো ওসিআর ও মেটাডাটা ব্যবহার করে তথ্য চুরি করে।",
            simulatedExif = SimulatedExif(
                deviceModel = "Google Pixel 9 Pro XL",
                cameraLens = "50MP Wide Camera, f/1.68, ISO 80",
                timestamp = "2026-11-05 10:30:45 GMT+6",
                gpsCoordinates = "23.7771° N, 90.3994° E (Mohakhali DOHS)",
                locationName = "Corporate Tech Hub, Mohakhali",
                serialNumber = "GGL-9P88X19B",
                privacyRisk = "CRITICAL: Exposes company facility coordinates, office security layout, and identity numbers.",
                privacyRiskBn = "মারাত্মক ঝুঁকি: অফিসের অবস্থান, সিকিউরিটি ব্যাজ এবং প্রাতিষ্ঠানিক গোপনীয়তা ফাঁস করে।"
            )
        )
    )

    val phishingUrlChecks = listOf(
        PhishingUrlCheck(
            fakeUrl = "https://accounts.tk-secur1ty-lab.com/login",
            legitUrl = "https://accounts.tk-security-lab.com/login",
            techniqueEn = "Typo-squatting / Character substitution ('1' instead of 'i')",
            techniqueBn = "টাইপো-স্কোয়াটিং বা অক্ষর প্রতিস্থাপন ('i' এর জায়গায় '1')",
            riskRating = "CRITICAL"
        ),
        PhishingUrlCheck(
            fakeUrl = "https://tk-security.lab-account-verify.xyz/auth",
            legitUrl = "https://tk-security.com/login",
            techniqueEn = "Subdomain spoofing: legit brand used as prefix on malicious .xyz domain",
            techniqueBn = "সাবডোমেন বিভ্রান্তি: প্রতারণামূলক .xyz ডোমেনের পূর্বে ব্র্যান্ড নাম ব্যবহার",
            riskRating = "HIGH"
        ),
        PhishingUrlCheck(
            fakeUrl = "https://login.tk-secսrity-lab.com",
            legitUrl = "https://login.tk-security-lab.com",
            techniqueEn = "IDN Homograph / Punycode: Cyrillic 'ս' (U+057D) mimics Latin 'u'",
            techniqueBn = "হোমোগ্রাফ অ্যাটাক / পিউনিকোড: দেখতে একই রকম সিরিলিক বর্ণ ব্যবহার",
            riskRating = "CRITICAL"
        )
    )

    val mockMalwareApps = listOf(
        MockMalwareApp(
            id = "app_flashlight",
            name = "Flashlight Pro Ultra 2026",
            packageName = "com.ultra.bright.flashlight.free",
            version = "4.2.1",
            iconCategory = "FLASHLIGHT",
            severity = ThreatSeverity.CRITICAL,
            suspiciousPermissions = listOf(
                "android.permission.RECEIVE_SMS",
                "android.permission.READ_CONTACTS",
                "android.permission.SYSTEM_ALERT_WINDOW",
                "android.permission.RECORD_AUDIO"
            ),
            descriptionEn = "A simple utility requesting banking overlay permissions and SMS interception capability. Often used as a Banking Trojan dropper.",
            descriptionBn = "একটি সাধারণ টর্চ অ্যাপ যা সন্দেহজনকভাবে ওটিপি ও এসএমএস পড়ার এবং স্ক্রিনে ফেক ওভারলে দেওয়ার অনুমতি চায়।",
            attackVectorEn = "Overlay Attack: Displays an invisible fake login window on top of legitimate banking apps to steal 2FA SMS and PINs.",
            attackVectorBn = "ওভারলে অ্যাটাক: আসল ব্যাংকিং অ্যাপের ওপর ভুয়া উইন্ডো দেখিয়ে ওটিপি এবং পিন চুরি করে।"
        ),
        MockMalwareApp(
            id = "app_cleaner",
            name = "Speed Booster & Battery Saver",
            packageName = "com.fastclean.rambooster.battery",
            version = "3.8.0",
            iconCategory = "SPEED",
            severity = ThreatSeverity.HIGH,
            suspiciousPermissions = listOf(
                "android.permission.BIND_ACCESSIBILITY_SERVICE",
                "android.permission.REQUEST_INSTALL_PACKAGES",
                "android.permission.ACCESS_FINE_LOCATION"
            ),
            descriptionEn = "Abuses Android Accessibility Service to autonomously click buttons, install secondary unverified APKs, and bypass user consent.",
            descriptionBn = "অ্যাক্সেসিবিলিটি সার্ভিসের অপব্যবহার করে ব্যাকগ্রাউন্ডে স্বয়ংক্রিয়ভাবে ক্ষতিকর কোড চালায় ও অন্যান্য অ্যাপ ইনস্টল করে।",
            attackVectorEn = "Accessibility Hijacking: Silently reads screen contents and accepts permissions without user physical interaction.",
            attackVectorBn = "স্ক্রিনের তথ্য গোপনে পর্যবেক্ষণ ও অনুমতি ছাড়া ব্যাকগ্রাউন্ডে পরিবর্তন।"
        ),
        MockMalwareApp(
            id = "app_streamer",
            name = "Cinema HD Movies Free",
            packageName = "org.moviezone.stream.premium",
            version = "1.0.4",
            iconCategory = "MOVIE",
            severity = ThreatSeverity.HIGH,
            suspiciousPermissions = listOf(
                "android.permission.CAMERA",
                "android.permission.READ_PHONE_STATE",
                "android.permission.WRITE_EXTERNAL_STORAGE"
            ),
            descriptionEn = "Side-loaded pirate streaming APK carrying background cryptomining payload and ad-fraud telemetry scripts.",
            descriptionBn = "অযাচিত সাইট থেকে নামানো স্ট্রিমিং অ্যাপ যা ডিভাইসের প্রসেসর ব্যবহার করে ক্রিপ্টো মাইনিং ও ডেটা চুরি করে।",
            attackVectorEn = "Resource Hijacking & Tracking: Overheats CPU, drains battery, and extracts device IMEI/IMSI identifiers.",
            attackVectorBn = "ডিভাইসের প্রসেসর শোষণ, অতিরিক্ত ব্যাটারি ক্ষয় এবং আইএমইআই ট্র্যাকিং।"
        ),
        MockMalwareApp(
            id = "app_clean_browser",
            name = "TK Link Verified Browser",
            packageName = "com.tklink.security.browser",
            version = "2.1.0",
            iconCategory = "BROWSER",
            severity = ThreatSeverity.SAFE,
            suspiciousPermissions = listOf(
                "android.permission.INTERNET"
            ),
            descriptionEn = "Verified application implementing least-privilege principles, sandboxed browsing, and anti-phishing protection.",
            descriptionBn = "যাচাইকৃত বিশ্বস্ত অ্যাপ যা কঠোর নিরাপত্তা নীতি অনুসরণ করে এবং অপ্রয়োজনীয় কোনো অনুমতি নেয় না।",
            attackVectorEn = "No Vulnerabilities Detected: Zero excessive permissions, strict HTTPS enforcement, verified developer certificate.",
            attackVectorBn = "কোনো ঝুঁকি পাওয়া যায়নি: বিশ্বস্ত ডিজিটাল স্বাক্ষর ও সীমিত অনুমতি।"
        )
    )

    // Complete standalone Web Source Code (HTML, CSS, JS) provided for educational dissemination
    val webHtmlCode = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TK Link Security Lab - Cybersecurity Awareness</title>
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;600&family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
</head>
<body class="cyber-theme">
  <!-- Disclaimer Banner -->
  <aside class="disclaimer-banner">
    <div class="banner-content">
      <span class="badge warning-badge">SAFE SIMULATION ONLY</span>
      <p id="disclaimer-text">Educational lab for security awareness. Zero credential harvesting, zero hidden access, no data leaves your browser.</p>
    </div>
    <button id="lang-toggle-btn" class="lang-btn" onclick="toggleLanguage()">বাংলা / English</button>
  </aside>

  <!-- Header -->
  <header class="cyber-header">
    <div class="brand">
      <div class="logo-shield">🛡️</div>
      <div>
        <h1 class="glow-text">TK LINK SECURITY LAB</h1>
        <p class="subtitle" id="sub-title">Phishing & Privacy Threat Defense Operations</p>
      </div>
    </div>
    <div class="threat-status">
      <div class="status-radar"></div>
      <span class="status-indicator live">THREAT MONITOR: ACTIVE</span>
    </div>
  </header>

  <!-- Main Navigation Tabs -->
  <nav class="lab-nav">
    <button class="nav-btn active" onclick="switchLab('photo-lab')">1. Photo Upload Phishing</button>
    <button class="nav-btn" onclick="switchLab('login-lab')">2. Fake Login Interceptor</button>
    <button class="nav-btn" onclick="switchLab('camera-lab')">3. Camera Permission Sandbox</button>
    <button class="nav-btn" onclick="switchLab('malware-lab')">4. Malware App Dashboard</button>
    <button class="nav-btn" onclick="switchLab('guide-lab')">5. Setup & Source Code</button>
  </nav>

  <!-- Content Container -->
  <main class="lab-main">
    <!-- Lab 1: Photo Upload Website -->
    <section id="photo-lab" class="lab-section active">
      <div class="section-header">
        <h2>Category 1: Malicious Photo Upload & EXIF Privacy Leak</h2>
        <p class="desc">Demonstrates how innocent photo sharing websites extract hidden GPS coordinates, camera hardware serials, and biometric facial data.</p>
      </div>
      <div class="lab-grid">
        <div class="cyber-card">
          <h3>Voluntary Image Upload Demonstration</h3>
          <p class="card-hint">Select a local image voluntarily. The file is processed purely on-device using the HTML5 FileReader API. No data is transmitted.</p>
          <div class="upload-zone" id="drop-zone" onclick="document.getElementById('file-input').click()">
            <div class="upload-icon">📸</div>
            <p>Click or Drop an image here to preview</p>
            <input type="file" id="file-input" accept="image/*" style="display:none" onchange="handleImageSelect(event)">
          </div>
          <div id="image-preview-container" class="preview-box" style="display:none">
            <img id="image-preview" alt="Preview">
            <div class="preview-meta">
              <span id="file-name-display">sample.jpg</span>
              <button class="btn btn-outline" onclick="resetImage()">Remove Photo</button>
            </div>
          </div>
        </div>

        <div class="cyber-card threat-intel">
          <h3>Simulated EXIF & Geotag Extractor</h3>
          <div id="exif-results" class="exif-panel">
            <div class="exif-row"><span class="key">GPS Location:</span> <span class="val highlight">23.8103° N, 90.4125° E (Dhaka)</span></div>
            <div class="exif-row"><span class="key">Device Model:</span> <span class="val">Samsung SM-S928B (Galaxy S24 Ultra)</span></div>
            <div class="exif-row"><span class="key">Camera Serial:</span> <span class="val">SEC-9981-R5CT</span></div>
            <div class="exif-row"><span class="key">Timestamp:</span> <span class="val">2026-11-10 19:42:18 GMT+6</span></div>
          </div>
          <div class="warning-callout">
            <h4>🚨 Threat Vector Breakdown:</h4>
            <ul>
              <li><strong>Stalking & Doxxing:</strong> Attackers cross-reference EXIF GPS coordinates to locate victims' homes.</li>
              <li><strong>Biometric Harvesting:</strong> Photos uploaded to unauthorized sites are scraped for facial recognition models.</li>
              <li><strong>Defense Rule:</strong> Scrub EXIF data using privacy tools or screenshot images before uploading.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <!-- Lab 2: Fake Login Page -->
    <section id="login-lab" class="lab-section">
      <div class="section-header">
        <h2>Category 2: Fake Login Page & Credential Interception</h2>
        <p class="desc">A realistic corporate single sign-on portal demonstrating typo-squatting, fake SSL security perception, and immediate attack interception.</p>
      </div>
      <div class="lab-grid">
        <div class="cyber-card login-portal">
          <div class="browser-bar">
            <span class="ssl-padlock">🔒</span>
            <span class="fake-url">https://<strong class="typo">tk-secur1ty-lab</strong>.com/oauth2/login</span>
          </div>
          <div class="login-form-box">
            <div class="brand-mini">🛡️ TK-Cloud SSO</div>
            <p class="sub">Sign in to Corporate Account</p>
            <div class="input-group">
              <label>Work Email</label>
              <input type="text" id="demo-user" placeholder="user@company.com" value="employee@cybercorp.com">
            </div>
            <div class="input-group">
              <label>Password (Dummy credentials only)</label>
              <input type="password" id="demo-pass" placeholder="Enter dummy text">
              <small class="live-warning">⚠️ Notice: Attack scripts capture text keystroke-by-keystroke!</small>
            </div>
            <button class="btn btn-primary" onclick="simulateLoginIntercept()">Sign In & Intercept Phish</button>
            <p class="safe-note">🛡️ Zero credentials saved. Purely educational simulation.</p>
          </div>
        </div>

        <div class="cyber-card">
          <h3>Phishing Intercept Analysis</h3>
          <div id="phish-analysis-box" class="analysis-box empty">
            <p>Click "Sign In" to view how the attack intercepts credentials.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Lab 3: Camera Permission Phishing -->
    <section id="camera-lab" class="lab-section">
      <div class="section-header">
        <h2>Category 3: Camera Permission Phishing & Privacy Sandbox</h2>
        <p class="desc">Reveals how rogue websites craft deceptive prompts to trick users into granting permanent camera and microphone access.</p>
      </div>
      <div class="lab-grid">
        <div class="cyber-card">
          <h3>Social Engineering Prompt Simulator</h3>
          <div class="deceptive-modal">
            <div class="modal-header">🎉 Congratulation! Claim 500 BDT Bonus</div>
            <p>Please allow face verification to confirm you are a real human!</p>
            <div class="fake-permission-prompt">
              <div class="prompt-icon">🎥</div>
              <div>
                <strong>"bonus-reward-gateway.xyz" wants to:</strong>
                <p>Use your camera</p>
              </div>
            </div>
            <div class="prompt-actions">
              <button class="btn btn-danger" onclick="triggerCameraWarning('Block')">Block</button>
              <button class="btn btn-primary" onclick="triggerCameraWarning('Allow')">Allow Camera</button>
            </div>
          </div>
        </div>

        <div class="cyber-card">
          <h3>Camera Security Deep Dive</h3>
          <div class="warning-callout">
            <h4>🔍 What Rogue Sites Attempt:</h4>
            <ul>
              <li><strong>Silent Snapshots:</strong> Captures high-res photos every few seconds while user reads an article.</li>
              <li><strong>Room & Identity Profiling:</strong> AI scans user surroundings, family members, and workspace documents.</li>
              <li><strong>Defensive Best Practices:</strong>
                <br>• Use "Ask Every Time" or "Only This Time".
                <br>• Watch for the Android green privacy dot in the status bar!
                <br>• Periodically audit camera permissions in browser settings.
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <!-- Lab 4: Malicious Application Awareness -->
    <section id="malware-lab" class="lab-section">
      <div class="section-header">
        <h2>Category 4: Malicious Android Application Dashboard</h2>
        <p class="desc">Interactive malware scanner analyzing fictional mobile applications for dangerous permissions, overlay abuses, and trojan droppers.</p>
      </div>
      <div class="scanner-toolbar">
        <button class="btn btn-primary btn-scan" id="scan-btn" onclick="runSimulatedScan()">⚡ Start Deep Threat Scan</button>
        <span id="scan-status" class="scan-status-text">System Ready</span>
      </div>
      <div class="scan-progress-bar" id="progress-container" style="display:none">
        <div class="progress-fill" id="progress-fill"></div>
      </div>
      <div class="app-list-grid" id="apps-container">
        <!-- Rendered via JavaScript -->
      </div>
    </section>

    <!-- Lab 5: Source Code & Setup Guide -->
    <section id="guide-lab" class="lab-section">
      <div class="section-header">
        <h2>Category 5: Source Code & Lab Setup Instructions</h2>
        <p class="desc">Deploy TK Link Security Lab in educational institutes, cybersecurity workshops, or internal corporate awareness programs.</p>
      </div>
      <div class="cyber-card">
        <h3>Local Deployment Instructions</h3>
        <pre class="code-block">
# 1. Clone or extract the lab files
mkdir tk-link-security-lab && cd tk-link-security-lab

# 2. Run with Python 3:
python3 -m http.server 8080

# 3. Or run with Node.js:
npx serve .

# 4. Open in browser:
http://localhost:8080
        </pre>
      </div>
    </section>
  </main>

  <footer class="cyber-footer">
    <p>TK Link Security Lab &copy; 2026. Built strictly for ethical defense, cybersecurity education & research.</p>
  </footer>

  <script src="app.js"></script>
</body>
</html>"""

    val webCssCode = """:root {
  --bg-dark: #070B14;
  --surface: #0F172A;
  --surface-card: #162036;
  --neon-cyan: #00E5FF;
  --neon-purple: #BD00FF;
  --neon-blue: #2979FF;
  --neon-green: #00E676;
  --neon-red: #FF1744;
  --text-main: #F8FAFC;
  --text-sub: #94A3B8;
  --border-glow: 1px solid rgba(0, 229, 255, 0.3);
}

* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body.cyber-theme {
  background-color: var(--bg-dark);
  color: var(--text-main);
  font-family: 'Inter', sans-serif;
  min-height: 100vh;
  padding: 16px;
  background-image: radial-gradient(circle at 10% 20%, rgba(189, 0, 255, 0.08) 0%, transparent 40%),
                    radial-gradient(circle at 90% 80%, rgba(0, 229, 255, 0.08) 0%, transparent 40%);
}

.disclaimer-banner {
  background: rgba(22, 32, 54, 0.9);
  border: 1px solid rgba(255, 171, 0, 0.4);
  border-radius: 8px;
  padding: 12px 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.warning-badge {
  background: #FFAB00;
  color: #000;
  padding: 3px 8px;
  border-radius: 4px;
  font-weight: 800;
  font-size: 11px;
}

.lang-btn {
  background: linear-gradient(135deg, var(--neon-cyan), var(--neon-purple));
  color: #000;
  font-weight: 700;
  border: none;
  border-radius: 6px;
  padding: 6px 14px;
  cursor: pointer;
}

.cyber-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
  border-bottom: var(--border-glow);
  padding-bottom: 16px;
}

.brand {
  display: flex;
  align-items: center;
  gap: 16px;
}

.logo-shield {
  font-size: 38px;
  filter: drop-shadow(0 0 10px var(--neon-cyan));
}

.glow-text {
  font-size: 24px;
  letter-spacing: 1.5px;
  color: var(--neon-cyan);
  text-shadow: 0 0 12px rgba(0, 229, 255, 0.6);
}

.subtitle {
  color: var(--text-sub);
  font-size: 13px;
}

.lab-nav {
  display: flex;
  gap: 10px;
  overflow-x: auto;
  margin-bottom: 24px;
  padding-bottom: 8px;
}

.nav-btn {
  background: var(--surface);
  border: 1px solid rgba(255, 255, 255, 0.1);
  color: var(--text-sub);
  padding: 10px 18px;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.25s ease;
}

.nav-btn:hover, .nav-btn.active {
  background: rgba(0, 229, 255, 0.12);
  border-color: var(--neon-cyan);
  color: var(--neon-cyan);
  box-shadow: 0 0 10px rgba(0, 229, 255, 0.2);
}

.lab-section {
  display: none;
}

.lab-section.active {
  display: block;
}

.section-header {
  margin-bottom: 20px;
}

.section-header h2 {
  color: var(--neon-purple);
  margin-bottom: 6px;
}

.section-header .desc {
  color: var(--text-sub);
  font-size: 14px;
}

.lab-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 20px;
}

.cyber-card {
  background: var(--surface-card);
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.08);
  padding: 20px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.5);
}

.upload-zone {
  border: 2px dashed rgba(0, 229, 255, 0.4);
  border-radius: 10px;
  padding: 30px;
  text-align: center;
  cursor: pointer;
  margin-top: 14px;
  transition: 0.2s;
}

.upload-zone:hover {
  background: rgba(0, 229, 255, 0.05);
  border-color: var(--neon-cyan);
}

.upload-icon {
  font-size: 36px;
  margin-bottom: 8px;
}

.preview-box {
  margin-top: 16px;
}

.preview-box img {
  width: 100%;
  max-height: 220px;
  object-fit: cover;
  border-radius: 8px;
  border: 1px solid var(--neon-cyan);
}

.preview-meta {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 10px;
}

.exif-panel {
  background: #090E18;
  border-radius: 8px;
  padding: 12px;
  margin: 14px 0;
  font-family: 'Fira Code', monospace;
  font-size: 12px;
}

.exif-row {
  margin-bottom: 8px;
}

.exif-row .key {
  color: var(--text-sub);
}

.exif-row .val {
  color: var(--neon-cyan);
}

.warning-callout {
  background: rgba(255, 23, 68, 0.08);
  border-left: 4px solid var(--neon-red);
  padding: 12px;
  border-radius: 4px;
  margin-top: 16px;
}

.warning-callout h4 {
  color: var(--neon-red);
  margin-bottom: 8px;
}

.warning-callout ul {
  padding-left: 18px;
  color: var(--text-sub);
  font-size: 13px;
  line-height: 1.6;
}

.browser-bar {
  background: #0B1120;
  padding: 8px 12px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  margin-bottom: 16px;
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.browser-bar .typo {
  color: var(--neon-red);
  text-decoration: underline;
}

.input-group {
  margin-bottom: 14px;
}

.input-group label {
  display: block;
  font-size: 12px;
  color: var(--text-sub);
  margin-bottom: 4px;
}

.input-group input {
  width: 100%;
  background: #080C14;
  border: 1px solid rgba(255, 255, 255, 0.15);
  padding: 10px;
  border-radius: 6px;
  color: #FFF;
  outline: none;
}

.input-group input:focus {
  border-color: var(--neon-purple);
}

.btn {
  padding: 10px 16px;
  border-radius: 6px;
  border: none;
  font-weight: 700;
  cursor: pointer;
}

.btn-primary {
  background: linear-gradient(135deg, var(--neon-cyan), var(--neon-blue));
  color: #000;
  width: 100%;
}

.btn-danger {
  background: var(--neon-red);
  color: #FFF;
}

.btn-outline {
  background: transparent;
  border: 1px solid var(--text-sub);
  color: var(--text-sub);
}

.code-block {
  background: #05080E;
  padding: 16px;
  border-radius: 8px;
  font-family: 'Fira Code', monospace;
  color: var(--neon-cyan);
  font-size: 13px;
  overflow-x: auto;
}

.cyber-footer {
  text-align: center;
  margin-top: 40px;
  padding: 20px;
  border-top: 1px solid rgba(255, 255, 255, 0.05);
  font-size: 12px;
  color: var(--text-sub);
}
"""

    val webJsCode = """// TK Link Security Lab - Interactive Educational Logic
let currentLanguage = 'EN';

const translations = {
  EN: {
    disclaimer: "Educational lab for security awareness. Zero credential harvesting, zero hidden access, no data leaves your browser.",
    subTitle: "Phishing & Privacy Threat Defense Operations"
  },
  BN: {
    disclaimer: "শিক্ষামূলক সাইবার নিরাপত্তা ল্যাব। কোনো পাসওয়ার্ড বা গোপন ডেটা সংরক্ষণ হয় না।",
    subTitle: "ফিশিং এবং গোপনীয়তা ঝুঁকি প্রতিরোধ ও সচেতনতা ল্যাব"
  }
};

function toggleLanguage() {
  currentLanguage = currentLanguage === 'EN' ? 'BN' : 'EN';
  document.getElementById('disclaimer-text').textContent = translations[currentLanguage].disclaimer;
  document.getElementById('sub-title').textContent = translations[currentLanguage].subTitle;
}

function switchLab(tabId) {
  document.querySelectorAll('.lab-section').forEach(sec => sec.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
  document.getElementById(tabId).classList.add('active');
  event.target.classList.add('active');
}

function handleImageSelect(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(e) {
    document.getElementById('image-preview').src = e.target.result;
    document.getElementById('file-name-display').textContent = file.name + " (" + (file.size/1024).toFixed(1) + " KB)";
    document.getElementById('image-preview-container').style.display = 'block';
    document.getElementById('drop-zone').style.display = 'none';
  };
  reader.readAsDataURL(file);
}

function resetImage() {
  document.getElementById('file-input').value = '';
  document.getElementById('image-preview-container').style.display = 'none';
  document.getElementById('drop-zone').style.display = 'block';
}

function simulateLoginIntercept() {
  const pass = document.getElementById('demo-pass').value;
  const analysisBox = document.getElementById('phish-analysis-box');
  analysisBox.className = 'analysis-box active';
  analysisBox.innerHTML = `
    <div style="background:rgba(255,23,68,0.15); border:1px solid #FF1744; border-radius:8px; padding:14px;">
      <h4 style="color:#FF1744; margin-bottom:8px;">🚨 CREDENTIAL PHISHING INTERCEPTED!</h4>
      <p style="font-size:13px; margin-bottom:8px;"><strong>Simulated Stolen Secret:</strong> <span style="font-family:monospace; color:#00E5FF;">` + (pass ? '•'.repeat(pass.length) + ' (' + pass.length + ' chars)' : 'empty') + `</span></p>
      <p style="font-size:12px; color:#CBD5E1; line-height:1.5;">
        <strong>How it works:</strong> The URL <code>tk-secur1ty-lab.com</code> mimics the real portal. Malicious forms forward submitted keystrokes to an attacker-controlled server before redirecting to the real site to hide the intrusion.
      </p>
      <div style="margin-top:10px; font-size:12px; color:#00E676;">
        <strong>🛡️ Defense:</strong> Password managers automatically refuse to autofill on mismatched domain names!
      </div>
    </div>
  `;
}

function triggerCameraWarning(action) {
  alert("SIMULATION RESULT (" + action + "):\n\nNever grant camera permissions to untrusted reward sites or suspicious links. On Android 12+, notice the green camera dot in the top corner whenever any app activates the sensor!");
}

const mockApps = [
  { name: "Flashlight Ultra 2026", pkg: "com.flashlight.ultra", severity: "CRITICAL", vector: "Overlay Trojan + SMS Read" },
  { name: "Speed RAM Booster", pkg: "com.booster.ram", severity: "HIGH", vector: "Accessibility Service Abuse" },
  { name: "Cinema HD Streamer", pkg: "org.movie.free", severity: "HIGH", vector: "Cryptomining & Ad-Fraud" },
  { name: "TK Link Verified Browser", pkg: "com.tklink.browser", severity: "SAFE", vector: "Verified Clean" }
];

function runSimulatedScan() {
  const progressContainer = document.getElementById('progress-container');
  const progressFill = document.getElementById('progress-fill');
  const status = document.getElementById('scan-status');
  const container = document.getElementById('apps-container');

  progressContainer.style.display = 'block';
  status.textContent = "Scanning installed applications...";
  container.innerHTML = '';

  let pct = 0;
  const timer = setInterval(() => {
    pct += 25;
    progressFill.style.width = pct + '%';
    if (pct >= 100) {
      clearInterval(timer);
      status.textContent = "Scan Complete: 3 Potential Threats Flagged";
      renderApps();
    }
  }, 300);
}

function renderApps() {
  const container = document.getElementById('apps-container');
  container.innerHTML = mockApps.map(app => `
    <div class="cyber-card" style="border-left: 4px solid ` + (app.severity === 'SAFE' ? '#00E676' : '#FF1744') + `">
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <strong>` + app.name + `</strong>
        <span style="font-size:11px; padding:2px 8px; border-radius:4px; background:` + (app.severity === 'SAFE' ? '#00E676' : '#FF1744') + `; color:#000; font-weight:800;">` + app.severity + `</span>
      </div>
      <p style="font-size:12px; color:#94A3B8; margin:4px 0;">` + app.pkg + `</p>
      <p style="font-size:12px; color:#F8FAFC;"><strong>Vector:</strong> ` + app.vector + `</p>
    </div>
  `).join('');
}
"""

    val localDeploymentGuide = """# TK Link Security Lab - Deployment Guide

### Overview
TK Link Security Lab is designed for schools, universities, cybersecurity bootcamps, and enterprise awareness programs. It provides zero-risk, realistic demonstrations of:
1. Malicious Photo Upload websites & EXIF privacy leaks
2. Fake Login pages & Credential Interception
3. Camera Permission Phishing & Social Engineering
4. Malicious Android Applications & Permission Abuse

### Local Setup Instructions:
1. Ensure Python 3 or Node.js is installed on your machine.
2. Save index.html, style.css, and app.js into a directory named `tk-link-security-lab`.
3. Launch a local web server:
   `python3 -m http.server 8080`
   or
   `npx serve .`
4. Access the dashboard in any modern browser at:
   `http://localhost:8080`

### Ethical Safety Statement
This lab never connects to external command-and-control servers, never transmits or stores credentials, and never secretly records audio or video. All exercises operate strictly on-device.
"""
}
