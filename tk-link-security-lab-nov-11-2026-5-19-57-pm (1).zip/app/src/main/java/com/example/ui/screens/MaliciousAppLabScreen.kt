package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Web
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SecurityLabData
import com.example.model.AppLanguage
import com.example.model.MockMalwareApp
import com.example.model.ThreatSeverity
import com.example.ui.components.CyberCard
import com.example.ui.components.SafeLabDisclaimer
import com.example.ui.components.ThreatBadge
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

@Composable
fun MaliciousAppLabScreen(
    currentLanguage: AppLanguage,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var isScanning by remember { mutableStateOf(false) }
    var scanProgress by remember { mutableFloatStateOf(0f) }
    var scanStatusText by remember { mutableStateOf("System Ready • Awaiting Scan") }
    var expandedAppId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(isScanning) {
        if (isScanning) {
            scanProgress = 0f
            scanStatusText = "Analyzing APK Manifests & Permissions..."
            delay(400)
            scanProgress = 0.35f
            scanStatusText = "Inspecting Accessibility API Hooks & Overlays..."
            delay(500)
            scanProgress = 0.75f
            scanStatusText = "Checking Digital Signatures & Dropper Heuristics..."
            delay(400)
            scanProgress = 1.0f
            scanStatusText = "Scan Complete: 3 Potential Threats Identified!"
            isScanning = false
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Safe Lab Disclaimer
        SafeLabDisclaimer(currentLanguage = currentLanguage)

        // Lab Header Card
        CyberCard(borderColor = NeonRed.copy(alpha = 0.5f)) {
            Text(
                text = if (currentLanguage == AppLanguage.EN) "LAB 04: MALICIOUS ANDROID APP AWARENESS" else "ল্যাব ০৪: ক্ষতিকর অ্যান্ড্রয়েড অ্যাপ সচেতনতা",
                color = NeonRed,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 16.sp,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "Malware awareness dashboard demonstrating how rogue applications disguise themselves as innocent utilities to hijack banking OTPs, abuse Accessibility services, and deploy screen overlays."
                else
                    "ম্যালওয়্যার সচেতনতা ড্যাশবোর্ড। কীভাবে সাধারণ ইউটিলিটি অ্যাপের ছদ্মবেশে ওটিপি চুরি, অ্যাক্সেসিবিলিটি সার্ভিসের অপব্যবহার ও স্ক্রিন ওভারলে আক্রমণ চালানো হয় তার বিশ্লেষণ।",
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }

        // Section: Simulated Scanner Toolbar
        CyberCard(borderColor = NeonCyan.copy(alpha = 0.4f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) "Simulated Threat Scanner" else "সিমুলেটেড ম্যালওয়্যার স্ক্যানার",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = scanStatusText,
                        color = if (scanProgress >= 1f) NeonAmber else NeonCyan,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Button(
                    onClick = { isScanning = true },
                    enabled = !isScanning,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("start_scan_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Scan",
                        tint = Color.Black,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) "Scan" else "স্ক্যান",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            if (isScanning || scanProgress > 0f) {
                Spacer(modifier = Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { scanProgress },
                    color = NeonCyan,
                    trackColor = Color(0xFF1E2842),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                )
            }
        }

        // Section: Fictional Demo Apps Analyzed
        Text(
            text = if (currentLanguage == AppLanguage.EN) "DEMO APPLICATIONS ANALYZED" else "বিশ্লেষণকৃত পরীক্ষামূলক অ্যাপসমূহ",
            color = NeonCyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )

        SecurityLabData.mockMalwareApps.forEach { app ->
            val isExpanded = expandedAppId == app.id
            MalwareAppCard(
                app = app,
                isExpanded = isExpanded,
                currentLanguage = currentLanguage,
                onToggleExpand = {
                    expandedAppId = if (isExpanded) null else app.id
                }
            )
        }

        // Section: Warning Signs of Rogue Android Apps
        CyberCard(borderColor = NeonAmber.copy(alpha = 0.4f)) {
            Text(
                text = if (currentLanguage == AppLanguage.EN) "Top Warning Signs of Android Malware" else "ক্ষতিকর অ্যান্ড্রয়েড অ্যাপ চেনার ৫টি লক্ষণ",
                color = NeonAmber,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            MalwareWarningSign(
                number = "1",
                title = if (currentLanguage == AppLanguage.EN) "Unjustified Permission Requests" else "অযৌক্তিক ও অপ্রয়োজনীয় পারমিশন দাবি",
                desc = if (currentLanguage == AppLanguage.EN)
                    "A flashlight, calculator, or solitaire game has NO legitimate reason to ask for SMS, Contacts, or Camera permissions."
                else
                    "টর্চ বা ক্যালকুলেটর অ্যাপের কখনোই এসএমএস পড়া বা কন্টাক্টস দেখার অনুমতির প্রয়োজন হয় না।"
            )

            MalwareWarningSign(
                number = "2",
                title = if (currentLanguage == AppLanguage.EN) "Persistent Accessibility Service Demands" else "অ্যাক্সেসিবিলিটি পারমিশন চাওয়ার জোরাজুরি",
                desc = if (currentLanguage == AppLanguage.EN)
                    "Malware uses Accessibility APIs to silently tap buttons in the background, read banking screen contents, and defeat 2FA."
                else
                    "অ্যাক্সেসিবিলিটি পারমিশন পেলে ক্ষতিকর অ্যাপ গোপনে স্ক্রিন রিড করে ওটিপি ও পাসওয়ার্ড সংগ্রহ করতে পারে।"
            )

            MalwareWarningSign(
                number = "3",
                title = if (currentLanguage == AppLanguage.EN) "Rapid Battery Drain & Overheating" else "অস্বাভাবিক ব্যাটারি ক্ষয় ও ডিভাইস গরম হওয়া",
                desc = if (currentLanguage == AppLanguage.EN)
                    "Hidden cryptominers, botnet zombies, and continuous telemetry scripts peg CPU utilization even when the screen is locked."
                else
                    "স্ক্রিন লক থাকা অবস্থায়ও ব্যাকগ্রাউন্ডে ক্রিপ্টো মাইনিং বা ডেটা চুরির কারণে মোবাইল অতিরিক্ত গরম হয়।"
            )

            MalwareWarningSign(
                number = "4",
                title = if (currentLanguage == AppLanguage.EN) "Disappearing Launcher Icon" else "ইনস্টলের পর আইকন উধাও হয়ে যাওয়া",
                desc = if (currentLanguage == AppLanguage.EN)
                    "Trojan droppers hide their icon immediately after installation to make uninstallation difficult for ordinary users."
                else
                    "ইনস্টল করার সাথে সাথেই অ্যাপের আইকন উধাও হয়ে ব্যাকগ্রাউন্ডে সক্রিয় থাকা।"
            )
        }

        // Section: Mobile Defense Checklist
        CyberCard(borderColor = NeonGreen.copy(alpha = 0.4f)) {
            Text(
                text = if (currentLanguage == AppLanguage.EN) "🛡️ Smartphone Protection Protocol" else "🛡️ মোবাইল ডিভাইস সুরক্ষার নিয়ম",
                color = NeonGreen,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "• Keep 'Install Unknown Apps' disabled for all browsers and messaging apps.\n• Ensure Google Play Protect is actively scanning on your device.\n• Regularly review Android Settings > Apps > Special App Access > Display Over Other Apps.\n• Never download cracked APKs from Telegram channels, WhatsApp forwards, or pirated media forums."
                else
                    "• ব্রাউজার বা হোয়াটসঅ্যাপে 'Install Unknown Apps' সর্বদা বন্ধ রাখুন।\n• গুগল প্লে প্রোটেক্ট সক্রিয় রাখুন।\n• সেটিংস থেকে 'Display Over Other Apps' এবং 'Accessibility' পারমিশন পাওয়া অ্যাপগুলো নিয়মিত চেক করুন।\n• টেলিগ্রাম বা অপরিচিত সাইটের ক্র্যাক করা APK ইনস্টল করবেন না।",
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 17.sp
            )
        }
    }
}

@Composable
private fun MalwareAppCard(
    app: MockMalwareApp,
    isExpanded: Boolean,
    currentLanguage: AppLanguage,
    onToggleExpand: () -> Unit
) {
    val borderColor = when (app.severity) {
        ThreatSeverity.CRITICAL -> NeonRed
        ThreatSeverity.HIGH -> NeonAmber
        ThreatSeverity.SAFE -> NeonGreen
        else -> NeonBlue
    }

    Surface(
        color = CyberSurfaceCard,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onToggleExpand() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(borderColor.copy(alpha = 0.15f))
                            .border(1.dp, borderColor.copy(alpha = 0.6f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        val icon = when (app.iconCategory) {
                            "FLASHLIGHT" -> Icons.Default.FlashOn
                            "SPEED" -> Icons.Default.Speed
                            "MOVIE" -> Icons.Default.Movie
                            else -> Icons.Default.Web
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = app.name,
                            tint = borderColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Text(
                            text = app.name,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "${app.packageName} (v${app.version})",
                            color = TextSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    ThreatBadge(severity = app.severity)
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "Expand",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Expanded Threat Breakdown
            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) "ANALYSIS BREAKDOWN:" else "হুমকি বিশ্লেষণ:",
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) app.descriptionEn else app.descriptionBn,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Suspicious Permissions list
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) "Requested Permissions:" else "অনুরোধকৃত পারমিশনসমূহ:",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    app.suspiciousPermissions.forEach { perm ->
                        Row(
                            modifier = Modifier.padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (app.severity == ThreatSeverity.SAFE) NeonGreen else NeonRed)
                            )
                            Text(
                                text = perm,
                                color = if (app.severity == ThreatSeverity.SAFE) NeonGreen else NeonAmber,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Attack Vector Box
                    Surface(
                        color = Color(0xFF1B1425),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = if (currentLanguage == AppLanguage.EN) "Attack Vector:" else "আক্রমণ কৌশল:",
                                color = NeonPurple,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (currentLanguage == AppLanguage.EN) app.attackVectorEn else app.attackVectorBn,
                                color = Color(0xFFF3E8FF),
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MalwareWarningSign(
    number: String,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(NeonAmber.copy(alpha = 0.2f))
                .border(1.dp, NeonAmber, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                color = NeonAmber,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
            )
        }
        Column {
            Text(
                text = title,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = desc,
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }
    }
}
