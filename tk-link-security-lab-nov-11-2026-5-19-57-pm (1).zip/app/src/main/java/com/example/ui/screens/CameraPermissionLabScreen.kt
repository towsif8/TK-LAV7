package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.model.AppLanguage
import com.example.ui.components.CyberCard
import com.example.ui.components.SafeLabDisclaimer
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun CameraPermissionLabScreen(
    currentLanguage: AppLanguage,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var simulatedWebDecision by remember { mutableStateOf<String?>(null) }
    var realPermissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        realPermissionGranted = isGranted
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Safe Lab Disclaimer
        SafeLabDisclaimer(currentLanguage = currentLanguage)

        // Header Card
        CyberCard(borderColor = NeonBlue.copy(alpha = 0.5f)) {
            Text(
                text = if (currentLanguage == AppLanguage.EN) "LAB 03: CAMERA PERMISSION PHISHING & PRIVACY" else "ল্যাব ০৩: ক্যামেরা পারমিশন ও প্রাইভেসি স্যান্ডবক্স",
                color = NeonBlue,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 16.sp,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "Understand how deceptive websites use bait rewards to trick users into granting camera access, and how modern OS privacy indicators protect you."
                else
                    "প্রতারক ওয়েবসাইটগুলো কীভাবে লোভনীয় অফারের ফাঁদে ফেলে ক্যামেরার অনুমতি আদায় করে এবং অপারেটিং সিস্টেমের প্রাইভেসি ইন্ডিকেটর কীভাবে সুরক্ষা দেয়।",
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }

        // Section: Simulated Web Social Engineering Prompt
        CyberCard(borderColor = NeonPurple.copy(alpha = 0.5f)) {
            Text(
                text = if (currentLanguage == AppLanguage.EN) "1. Simulated Web Social Engineering Phish" else "১. ওয়েব সোশ্যাল ইঞ্জিনিয়ারিং সিমুলেশন",
                color = NeonPurple,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "Deceptive websites frequently disguise camera access as 'Human Face Verification' or 'Free Gift Card Claim':"
                else
                    "ক্ষতিকর সাইটগুলো রোবট ভেরিফিকেশন বা ফ্রি উপহারের নামে প্রতারণামূলক ক্যামেরা প্রম্পট তৈরি করে:",
                color = TextSecondary,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(12.dp))

            // The Deceptive Popup Box
            Surface(
                color = Color(0xFF141A2D),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(text = "🎁", fontSize = 20.sp)
                        Column {
                            Text(
                                text = "CLAIM 500 BDT BONUS GIFT CARD",
                                color = NeonCyan,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "Instant Reward Portal • Verification required",
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Mock Browser Permission Dialog Box
                    Surface(
                        color = Color(0xFF090E18),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF283856)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(NeonBlue.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Videocam,
                                    contentDescription = "Camera Icon",
                                    tint = NeonBlue,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "reward-bonus-claim.xyz",
                                    color = NeonAmber,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "wants to: Use your camera",
                                    color = TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Block vs Allow Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { simulatedWebDecision = "BLOCK" },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonRed),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("sim_block_camera_button")
                        ) {
                            Text(
                                text = if (currentLanguage == AppLanguage.EN) "Block (Safe)" else "ব্লক (নিরাপদ)",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        Button(
                            onClick = { simulatedWebDecision = "ALLOW" },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2E4E)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, NeonBlue),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("sim_allow_camera_button")
                        ) {
                            Text(
                                text = if (currentLanguage == AppLanguage.EN) "Simulate Allow" else "অনুমতি সিমুলেশন",
                                color = NeonBlue,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // Outcome Analysis
            AnimatedVisibility(visible = simulatedWebDecision != null) {
                Spacer(modifier = Modifier.height(10.dp))
                if (simulatedWebDecision == "BLOCK") {
                    Surface(
                        color = Color(0xFF13281E),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Safe",
                                tint = NeonGreen,
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                Text(
                                    text = if (currentLanguage == AppLanguage.EN) "CORRECT DEFENSIVE CHOICE!" else "সঠিক প্রতিরক্ষামূলক সিদ্ধান্ত!",
                                    color = NeonGreen,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = if (currentLanguage == AppLanguage.EN)
                                        "By blocking the untrusted domain, zero camera streams were opened. No image or biometric data was leaked."
                                    else
                                        "অপরিচিত ডোমেন ব্লক করার ফলে ক্যামেরার কোনো তথ্য বা ছবি ফাঁস হতে পারেনি।",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                } else {
                    Surface(
                        color = Color(0xFF2B1015),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Threat",
                                tint = NeonRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                Text(
                                    text = if (currentLanguage == AppLanguage.EN) "CRITICAL PRIVACY HAZARD!" else "মারাত্মক গোপনীয়তা ঝুঁকি!",
                                    color = NeonRed,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = if (currentLanguage == AppLanguage.EN)
                                        "In a real attack, allowing this grants continuous access to capture room telemetry, face markers, and background surroundings while the tab remains open!"
                                    else
                                        "বাস্তব আক্রমণে অনুমতি দিলে ক্ষতিকর সাইটটি ব্যাকগ্রাউন্ডে ক্রমাগত আপনার ছবি, রুমের পরিবেশ ও মুখের বায়োমেট্রিক তথ্য সংগ্রহ করতে পারে!",
                                    color = Color(0xFFFFB4AB),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section: Real Android Permission & Green Dot Privacy Indicator
        CyberCard(borderColor = NeonGreen.copy(alpha = 0.5f)) {
            Text(
                text = if (currentLanguage == AppLanguage.EN) "2. Android 12+ Privacy Dot Demonstration" else "২. অ্যান্ড্রয়েড প্রাইভেসি ডট সনাক্তকরণ",
                color = NeonGreen,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "Modern Android versions display a prominent green indicator in the top status bar whenever any app accesses camera sensors."
                else
                    "অ্যান্ড্রয়েড ১২ বা তার পরবর্তী সংস্করণে যেকোনো অ্যাপ ক্যামেরা ব্যবহার করলেই স্ট্যাটাস বারে একটি উজ্জ্বল সবুজ ডট জ্বলে ওঠে।",
                color = TextSecondary,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Indicator Visual Simulation
            Surface(
                color = Color(0xFF090E18),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E2840)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STATUS BAR SIMULATION",
                            color = TextSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(if (realPermissionGranted) NeonGreen else Color(0xFF283856))
                            )
                            Text(
                                text = if (realPermissionGranted) "CAMERA ACTIVE (GREEN DOT)" else "SENSOR IDLE",
                                color = if (realPermissionGranted) NeonGreen else TextSecondary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Safe Android Permission Test Trigger
            Button(
                onClick = {
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2842)),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonGreen),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("trigger_android_permission_button")
            ) {
                Icon(
                    imageVector = Icons.Default.PrivacyTip,
                    contentDescription = "Test Permission",
                    tint = NeonGreen,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (currentLanguage == AppLanguage.EN)
                        "Test Real Android Permission Dialog (Safe)"
                    else
                        "অ্যান্ড্রয়েড পারমিশন ডায়ালগ পরীক্ষা করুন (সম্পূর্ণ নিরাপদ)",
                    color = NeonGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "🛡️ Zero video recording: This triggers the system dialog for educational demonstration only."
                else
                    "🛡️ কোনো ভিডিও রেকর্ড বা সংরক্ষণ করা হয় না। শুধুমাত্র সিস্টেম ডায়ালগ প্রদর্শনের জন্য।",
                color = TextSecondary,
                fontSize = 10.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }

        // Section: What Malicious Actors Attempt with Camera Permissions
        CyberCard(borderColor = NeonAmber.copy(alpha = 0.4f)) {
            Text(
                text = if (currentLanguage == AppLanguage.EN) "Real-World Camera Attack Vectors" else "ক্যামেরা পারমিশনের অপব্যবহার পদ্ধতি",
                color = NeonAmber,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            CameraRiskPoint(
                number = "1",
                title = if (currentLanguage == AppLanguage.EN) "Covert Snapshot Harvesting" else "গোপনে ছবি সংগ্রহ",
                desc = if (currentLanguage == AppLanguage.EN)
                    "Malicious web scripts capture hidden WebRTC frames every 3 seconds without rendering a preview, transmitting faces to remote servers."
                else
                    "ব্যবহারকারীকে কোনো ছবি বা ভিডিও প্রিভিউ না দেখিয়েই ওয়েব স্ক্রিপ্ট ব্যাকগ্রাউন্ডে ছবি তুলে সার্ভারে পাঠাতে পারে।"
            )

            CameraRiskPoint(
                number = "2",
                title = if (currentLanguage == AppLanguage.EN) "Surroundings & Room Reconstruction" else "কক্ষ ও পরিবেশের তথ্য সংগ্রহ",
                desc = if (currentLanguage == AppLanguage.EN)
                    "Computer vision algorithms analyze objects in your background (calendars, diplomas, family photos, sensitive paper documents) for blackmail or targeted spear-phishing."
                else
                    "আপনার পেছনের দেওয়ালের ক্যালেন্ডার, টেবিলের ফাইল বা পারিবারিক ছবি বিশ্লেষণ করে ব্যক্তিগত তথ্য হাতিয়ে নেওয়া হয়।"
            )

            CameraRiskPoint(
                number = "3",
                title = if (currentLanguage == AppLanguage.EN) "Clickjacking & Overlay Bait" else "ক্লিকজ্যাকিং ও ওভারলে প্রতারণা",
                desc = if (currentLanguage == AppLanguage.EN)
                    "Attackers place an invisible browser permission prompt directly beneath a 'Play Game' or 'Solve CAPTCHA' button so a single user tap accidentally grants access."
                else
                    "গেম খেলা বা ক্যাপচা পূরণের বাটনের পেছনে গোপন ক্যামেরা পারমিশন বাটন রেখে ব্যবহারকারীর একটি ক্লিকেই অনুমতি আদায় করা।"
            )
        }

        // Section: Defense Rules
        CyberCard(borderColor = NeonCyan.copy(alpha = 0.4f)) {
            Text(
                text = if (currentLanguage == AppLanguage.EN) "🛡️ Defensive Recommendations" else "🛡️ ক্যামেরা সুরক্ষা টিপস",
                color = NeonCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "• Always select 'Only this time' or 'While using the app' on Android.\n• If the green camera dot appears unexpectedly, check which app is active immediately.\n• Audit permissions via Android Settings > Privacy > Privacy Dashboard > Camera.\n• Use a physical webcam slider for laptops and desktop devices."
                else
                    "• অ্যান্ড্রয়েডে সর্বদা 'Only this time' বা 'While using the app' নির্বাচন করুন।\n• অপ্রত্যাশিতভাবে সবুজ প্রাইভেসি ডট জ্বললে অবিলম্বে রিসেন্ট অ্যাপস চেক করুন।\n• সেটিংস > প্রাইভেসি > প্রাইভেসি ড্যাশবোর্ড থেকে কোন অ্যাপ ক্যামেরা ব্যবহার করেছে তা নিয়মিত পরীক্ষা করুন।\n• ল্যাপটপে ফিজিক্যাল ওয়েবক্যাম কভার ব্যবহার করুন।",
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 17.sp
            )
        }
    }
}

@Composable
private fun CameraRiskPoint(
    number: String,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(NeonAmber.copy(alpha = 0.2f))
                .border(1.dp, NeonAmber, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                color = NeonAmber,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
            )
        }
        Column {
            Text(
                text = title,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = desc,
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }
    }
}
