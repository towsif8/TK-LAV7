package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBackground = Color(0xFF070B14)
val CyberSurface = Color(0xFF0F172A)
val CyberSurfaceCard = Color(0xFF162036)
val CyberSurfaceElevated = Color(0xFF1E2B4A)
val CyberBorder = Color(0xFF2D3C61)

val NeonCyan = Color(0xFF00E5FF)
val NeonBlue = Color(0xFF2979FF)
val NeonPurple = Color(0xFFBD00FF)
val NeonMagenta = Color(0xFFD500F9)
val NeonViolet = Color(0xFF7C4DFF)

val NeonGreen = Color(0xFF00E676)
val NeonRed = Color(0xFFFF1744)
val NeonAmber = Color(0xFFFFAB00)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
