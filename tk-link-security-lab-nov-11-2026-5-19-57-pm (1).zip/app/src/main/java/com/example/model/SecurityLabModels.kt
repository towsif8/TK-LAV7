package com.example.model

enum class AppLanguage {
    EN, BN
}

enum class LabTab {
    DASHBOARD,
    PHOTO_UPLOAD,
    FAKE_LOGIN,
    CAMERA_PERMISSION,
    MALWARE_SCAN,
    SOURCE_SETUP,
    WEB_VIEW
}

enum class ThreatSeverity {
    SAFE,
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

data class SamplePhoto(
    val id: String,
    val nameEn: String,
    val nameBn: String,
    val category: String,
    val descriptionEn: String,
    val descriptionBn: String,
    val simulatedExif: SimulatedExif
)

data class SimulatedExif(
    val deviceModel: String,
    val cameraLens: String,
    val timestamp: String,
    val gpsCoordinates: String,
    val locationName: String,
    val serialNumber: String,
    val privacyRisk: String,
    val privacyRiskBn: String
)

data class MockMalwareApp(
    val id: String,
    val name: String,
    val packageName: String,
    val version: String,
    val iconCategory: String,
    val severity: ThreatSeverity,
    val suspiciousPermissions: List<String>,
    val descriptionEn: String,
    val descriptionBn: String,
    val attackVectorEn: String,
    val attackVectorBn: String
)

data class PhishingUrlCheck(
    val fakeUrl: String,
    val legitUrl: String,
    val techniqueEn: String,
    val techniqueBn: String,
    val riskRating: String
)
